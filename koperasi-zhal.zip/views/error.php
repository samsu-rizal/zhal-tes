<div class="main-panel">
			<nav class="navbar navbar-default">
				<div class="container-fluid">
					<div class="navbar-header">
						<a class="navbar-brand" href="#">DASHBOARD</a>
					</div>
				</div>
			</nav>

			<div class="content">
	<div class="container-fluid">
		<div class="row">

			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<h4 class="title">Oooppss!!!</h4>
					</div>
					<div class="content">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>Halaman yang anda cari tidak tersedia</label>
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>
		</div>
	</div>
</div>
</div>